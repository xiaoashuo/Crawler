package com.reptile.demo.service.impl;

import com.reptile.demo.dao.ItemDao;
import com.reptile.demo.pojo.JdItem;
import com.reptile.demo.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemServiceImpl implements ItemService {

    @Autowired
    ItemDao itemDao;

    @Override
    public void save(JdItem jdItem) {
        this.itemDao.save(jdItem);
    }

    @Override
    public List<JdItem> findAll(JdItem jdItem) {
        Example<JdItem> example=Example.of(jdItem);
        List<JdItem> items = itemDao.findAll(example);
        return items;
    }
}
