package com.reptile.demo.service;

import com.reptile.demo.pojo.JdItem;

import java.util.List;

public interface ItemService {
    public void save(JdItem jdItem);

    public List<JdItem> findAll(JdItem jdItem);
}
