package com.reptile.demo.pojo;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "jd_item")
public class JdItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    //标准产品单位
    private Long spu;
    //库存量单位（最小品类单元）
    private Long sku;
    //商品标题
    private String title;
    //图片地址
    private String pic;
    //超链接
    @Column(name = "go_url")
    private String goUrl;
    //价格
    private Double price;
    //详情
    private String detail;
    @Column(name = "create_date")
    private Date createDate;
}
