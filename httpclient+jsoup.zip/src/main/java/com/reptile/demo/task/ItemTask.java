package com.reptile.demo.task;

import com.reptile.demo.pojo.JdItem;
import com.reptile.demo.service.ItemService;
import com.reptile.demo.utils.HttpUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class ItemTask {

    @Autowired
    private HttpUtils httpUtils;

    @Autowired
    ItemService itemService;

    //固定间隔进行下一次任务 单位ms
    @Scheduled(fixedDelay = 100*1000)
    public void itemTask() throws Exception{
      //声明需要解析的初始地址
      String url="https://search.jd.com/Search?keyword=手机&enc=utf-8&qrst=1&rt=1&stop=1&vt=2&wq=手机&cid2=653&cid3=655&s=54&click=0&page=";
      //遍历页面
      for (int i=1;i<10;i=i+2){

          String html = httpUtils.doGetHtml(url + i);
          ///解析页面获取商品数据并存储
          this.parse(html);

      }
        System.out.println("手机数据抓取成功");
    }

    /**
     * 页面解析
     * @param html
     */
    private void parse(String html) {
        //解析html获取dom对象
        Document doc = Jsoup.parse(html);
        //获取spu
        Elements spuEles = doc.select("#J_goodsList > ul >li");
        spuEles.forEach(spuEle->{
            long spu = Long.parseLong(spuEle.attr("data-spu"));
            //获取sku
            Elements skuEles = spuEle.select("li.ps-item");
            for (Element skuEle:skuEles) {
                //获取sku
                long sku = Long.parseLong(skuEle.select("[data-sku]").attr("data-sku"));
                //根据sku查询商品是否存在
                JdItem jdItem=new JdItem();
                jdItem.setSku(sku);
                List<JdItem> jdItems = itemService.findAll(jdItem);
                //若存在不保存
                if (jdItems.size()>0){
                    continue;
                }
                //设置spu
                jdItem.setSpu(spu);
                //设置商品详情
                String itemUrl="https://item.jd.com/"+sku+".html";
                jdItem.setGoUrl(itemUrl);
                String pic = "https:"+skuEle.select("img[data-sku]").first().attr("data-lazy-img");
                 pic=pic.replace("/n9/","/n1/");
                String picName = this.httpUtils.doGetImage(pic);
                jdItem.setPic(picName);
               // jdItem.setTitle();
                //jdItem.setPrice();
                jdItem.setCreateDate(new Date());
            }

        });
    }
}
