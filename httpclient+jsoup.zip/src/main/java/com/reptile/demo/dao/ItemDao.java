package com.reptile.demo.dao;

import com.reptile.demo.pojo.JdItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemDao extends JpaRepository<JdItem,Long> {
}
