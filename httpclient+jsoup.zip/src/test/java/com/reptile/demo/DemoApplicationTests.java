package com.reptile.demo;

import com.reptile.demo.utils.HttpClientUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {

    @Test
    public void contextLoads() {
        String s = HttpClientUtils.get("https://search.jd.com/Search?keyword=%E6%89%8B%E6%9C%BA&enc=utf-8&qrst=1&rt=1&stop=1&vt=2&wq=%E6%89%8B%E6%9C%BA&cid2=653&cid3=655&s=54&click=0&page=1");
        System.out.println(s);
    /*    Document doc = Jsoup.parse(s);
        String title = doc.getElementsByTag("title")
                .first().text();
        System.out.println(title);*/


    }

    @Test
    public void jsoup() throws Exception {
        //1.url 2.超时时间
        Document doc = Jsoup.parse(new URL("https://www.baidu.com"), 10000);
        //使用标签选择器 获取title标签中的内容
        String title = doc.getElementsByTag("title").first().text();
        System.out.println(title);
    }

}
